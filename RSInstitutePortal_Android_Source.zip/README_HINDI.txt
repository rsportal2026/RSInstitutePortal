RS Institute Portal Android wrapper source

Website: https://rsportal.wuaze.com/
App name: RS Institute Portal

APK banane ka free tareeka:
1. Android Studio (https://developer.android.com/studio) computer par install karein.
2. Android Studio mein is ZIP ko extract karke RSInstitutePortal folder Open karein.
3. Gradle sync complete hone dein. Android SDK Platform 35 install karne ka prompt aaye to install karein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5. APK path aam taur par app/build/outputs/apk/debug/app-debug.apk hoga.
6. APK phone mein transfer karke install karein. Phone par unknown app install permission prompt aa sakta hai.

Important:
- Ye WebView wrapper hai, website ka content HTTPS link se load hota hai. Website online hona zaroori hai.
- Existing PHP/API/database hosting par hi rehte hain; APK mein PHP files embed nahi hoti.
- Pehle debug APK ko test karein. Production signing/keystore ko surakshit rakhna chahiye.
- File picker support included hai. Downloads ka behavior website/browser implementation par depend kar sakta hai.
