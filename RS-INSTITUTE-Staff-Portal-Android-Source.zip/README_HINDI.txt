RS INSTITUTE Staff Portal - Android source

App display name (launcher/install screen): RS Institute Staff Portal
APK output filename: RS-INSTITUTE-Staff-Portal.apk
Website: https://rsportal.wuaze.com/

Logo:
- Launcher icon is generated from the supplied logo-512.png.
- Density-specific icons are in app/src/main/res/mipmap-*.
- Original logo is also included at app/src/main/res/drawable/logo.png.

Build locally:
1. Open this project folder in Android Studio.
2. Allow Gradle sync; install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The normal Gradle output is app/build/outputs/apk/debug/app-debug.apk.
   Rename it to RS-INSTITUTE-Staff-Portal.apk if sharing manually.

GitHub Actions:
- Put the supplied main.yml at .github/workflows/main.yml in your repository.
- Put this source ZIP in the repository root.
- The workflow builds the debug APK and uploads it as the artifact
  RS-INSTITUTE-Staff-Portal containing RS-INSTITUTE-Staff-Portal.apk.

Important:
- This is a WebView wrapper. The website must remain online and reachable.
- PHP/API/database files remain on your hosting; they are not embedded in this APK.
- This is a debug build, not a Play Store release-signed APK.
- Existing WebView, file chooser, navigation, and website URL code are preserved.
